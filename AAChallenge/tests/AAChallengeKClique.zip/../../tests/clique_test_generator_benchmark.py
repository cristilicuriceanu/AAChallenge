# test_clique_algorithms.py

import time
import csv
import matplotlib.pyplot as plt
import pandas as pd

from src.clique_solver import (
    backtracking_exact,
    greedy_max_degree,
    hill_climbing,
    generate_adjacency_matrix
)

# =============================================================================
# CORRECTNESS + PERFORMANCE TESTS
# =============================================================================

def run_benchmarks():
    with open('correctness_results.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['density', 'nodes', 'exact', 'greedy', 'hill_climbing'])

        for density in [0.1, 0.3, 0.5, 0.7]:
            results = {
                'nodes': [],
                'exact_t': [],
                'greedy_t': [],
                'hill_t': [],
                'exact_s': [],
                'greedy_s': [],
                'hill_s': []
            }

            for i, nodes in enumerate(range(10, 60, 5)):
                matrix = generate_adjacency_matrix(nodes, density, seed=i)

                t0 = time.perf_counter()
                exact = backtracking_exact(matrix)
                exact_t = time.perf_counter() - t0

                t0 = time.perf_counter()
                greedy = greedy_max_degree(matrix)
                greedy_t = time.perf_counter() - t0

                t0 = time.perf_counter()
                hill = hill_climbing(matrix)
                hill_t = time.perf_counter() - t0

                writer.writerow([
                    density,
                    nodes,
                    1,
                    int(len(greedy) == len(exact)),
                    int(len(hill) == len(exact))
                ])

                results['nodes'].append(nodes)
                results['exact_t'].append(exact_t)
                results['greedy_t'].append(greedy_t)
                results['hill_t'].append(hill_t)
                results['exact_s'].append(len(exact))
                results['greedy_s'].append(len(greedy))
                results['hill_s'].append(len(hill))

            plot_results(results, density)

    print("All benchmarks completed.")


def plot_results(results, density):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    ax1.plot(results['nodes'], results['exact_t'], label='Exact')
    ax1.plot(results['nodes'], results['greedy_t'], label='Greedy')
    ax1.plot(results['nodes'], results['hill_t'], label='Hill')
    ax1.set_yscale('log')
    ax1.set_title(f'Execution Time (density={density})')
    ax1.set_xlabel('Nodes')
    ax1.set_ylabel('Time (s)')
    ax1.legend()
    ax1.grid(True)

    ax2.plot(results['nodes'], results['exact_s'], label='Exact')
    ax2.plot(results['nodes'], results['greedy_s'], label='Greedy')
    ax2.plot(results['nodes'], results['hill_s'], label='Hill')
    ax2.set_title(f'Clique Size (density={density})')
    ax2.set_xlabel('Nodes')
    ax2.set_ylabel('Size')
    ax2.legend()
    ax2.grid(True)

    plt.tight_layout()
    plt.savefig(f'benchmark_density_{density}.png')
    plt.show()


def view_results(filepath='correctness_results.csv'):
    df = pd.read_csv(filepath)

    print("=== Accuracy Summary ===")
    for col in ['exact', 'greedy', 'hill_climbing']:
        print(f"{col}: {df[col].sum()}/{len(df)}")

    print("\n=== Detailed Results ===")
    print(df)


if __name__ == "__main__":
    run_benchmarks()
    view_results()
