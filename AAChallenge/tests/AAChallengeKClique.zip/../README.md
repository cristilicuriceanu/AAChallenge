# Proiect AA (K-Clique) 
## Dragusoiu Bogdan Ioan
## Saveli Victor
## Licuriceanu Cristian

Acest proiect studiaza problema maximum clique (enuntata drept "K-Clique" in lista de probleme posibile)
Am folosit jupyter notebook, deoarece ni s-a parut ca s-ar potrivi perfect cu acest proiect.

Algoritmii alesi :

1) Backtracking exact -> Gaseste solutia exacta mereu dar este mai lent, devine mult mai lent pe seturi mai mari de date.
2) Greedy Max Degree -> O euristica care alege nodurile in functie de gradul acestora.
3) Hill Climbing -> Asemanator cu GMD, dar verifica daca mai poate extinde submultimea gasita curent.