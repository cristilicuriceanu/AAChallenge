Maximum Clique – Solver and Tests
=================================

This project contains two Python files: one for solving the Maximum Clique
problem and one for testing and benchmarking the algorithms.

--------------------------------------------------
Files
--------------------------------------------------

1) clique_solver.py

This file contains the core implementation of the Maximum Clique problem.

Algorithms:
- backtracking_exact      : exact solution using exhaustive backtracking
- greedy_max_degree       : greedy heuristic based on node degree
- hill_climbing           : local search heuristic

Utilities:
- random adjacency matrix generation
- CSV input/output helpers
- function to run all algorithms on a given graph

This file contains NO tests, plots, or benchmarking code and is meant to be
imported.

--------------------------------------------------

2) test_clique_algorithms.py

This file is used for testing and evaluation.

What it does:
- generates random graphs of different sizes and densities
- compares greedy and hill-climbing results to the exact solution
- measures execution time
- writes correctness results to a CSV file
- generates performance plots

This file imports functions from clique_solver.py and should be executed
directly.

--------------------------------------------------
How to Run
--------------------------------------------------

Run the tests from the project root:

python test_clique_algorithms.py

This will:
- generate correctness_results.csv
- generate benchmark_density_*.png plots
- print a summary of correctness results