# clique_solver.py

import csv
import random
from typing import List, Optional

# =============================================================================
# EXACT BACKTRACKING (MAXIMUM CLIQUE)
# =============================================================================

def backtracking_exact(adj_matrix: List[List[int]]) -> List[int]:
    n = len(adj_matrix)
    best_clique = []
    current_clique = []

    def is_adjacent(u: int, v: int) -> bool:
        return adj_matrix[u][v] == 1

    def is_clique_candidate(u: int) -> bool:
        return all(is_adjacent(u, v) for v in current_clique)

    def backtrack(start: int) -> None:
        nonlocal best_clique

        if len(current_clique) > len(best_clique):
            best_clique = current_clique.copy()

        if len(current_clique) + (n - start) <= len(best_clique):
            return

        for u in range(start, n):
            if is_clique_candidate(u):
                current_clique.append(u)
                backtrack(u + 1)
                current_clique.pop()

    backtrack(0)
    return sorted(best_clique)

# =============================================================================
# GREEDY MAX DEGREE HEURISTIC
# =============================================================================

def greedy_max_degree(adj_matrix: List[List[int]]) -> List[int]:
    n = len(adj_matrix)
    if n == 0:
        return []

    def degree(u: int) -> int:
        return sum(adj_matrix[u])

    def is_adjacent(u: int, v: int) -> bool:
        return adj_matrix[u][v] == 1

    used = [False] * n
    clique = []

    start = max(range(n), key=degree)
    clique.append(start)
    used[start] = True

    while True:
        best = -1
        best_deg = -1

        for u in range(n):
            if used[u]:
                continue
            if all(is_adjacent(u, v) for v in clique):
                d = degree(u)
                if d > best_deg:
                    best_deg = d
                    best = u

        if best == -1:
            break

        clique.append(best)
        used[best] = True

    return sorted(clique)

# =============================================================================
# HILL CLIMBING HEURISTIC
# =============================================================================

def hill_climbing(adj_matrix: List[List[int]]) -> List[int]:
    n = len(adj_matrix)
    if n == 0:
        return []

    def is_adjacent(u: int, v: int) -> bool:
        return adj_matrix[u][v] == 1

    def degree(u: int) -> int:
        return sum(adj_matrix[u])

    nodes = sorted(range(n), key=degree, reverse=True)
    clique = []

    for u in nodes:
        if all(is_adjacent(u, v) for v in clique):
            clique.append(u)

    improved = True
    while improved:
        improved = False
        clique_set = set(clique)

        for remove in clique:
            others = [v for v in clique if v != remove]
            candidates = [
                u for u in range(n)
                if u not in clique_set and all(is_adjacent(u, v) for v in others)
            ]

            for i in range(len(candidates)):
                for j in range(i + 1, len(candidates)):
                    if is_adjacent(candidates[i], candidates[j]):
                        clique = others + [candidates[i], candidates[j]]
                        improved = True
                        break
                if improved:
                    break
            if improved:
                break

    return sorted(clique)

# =============================================================================
# GRAPH UTILITIES
# =============================================================================

def generate_adjacency_matrix(
    num_nodes: int,
    density: float,
    seed: Optional[int] = None
) -> List[List[int]]:
    if seed is not None:
        random.seed(seed)

    matrix = [[0] * num_nodes for _ in range(num_nodes)]
    for i in range(num_nodes):
        for j in range(i + 1, num_nodes):
            if random.random() < density:
                matrix[i][j] = matrix[j][i] = 1
    return matrix


def read_matrix_from_csv(filepath: str) -> List[List[int]]:
    with open(filepath, newline='') as f:
        return [[int(x) for x in row] for row in csv.reader(f)]


def write_results_to_csv(filepath: str, results: dict) -> None:
    with open(filepath, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['algorithm', 'clique_size', 'clique_nodes'])
        for name, clique in results.items():
            writer.writerow([name, len(clique), ' '.join(map(str, clique))])


def run_all_algorithms(adj_matrix: List[List[int]], output_csv: str) -> dict:
    results = {
        'backtracking_exact': backtracking_exact(adj_matrix),
        'greedy_max_degree': greedy_max_degree(adj_matrix),
        'hill_climbing': hill_climbing(adj_matrix)
    }
    write_results_to_csv(output_csv, results)
    return results
